#ifndef _H_LightCustomCode
#define _H_LightCustomCode

// Put any C++ project-specific custom code here

#endif

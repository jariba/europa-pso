#ifndef _H_ShoppingCustomCode
#define _H_ShoppingCustomCode

// Put any C++ project-specific custom code here

#endif

package UBO;

public class ResourceViolationInfo 
{
    public int time;
    public double level;
    
    public ResourceViolationInfo(int t,double l)
    {
        time = t;
        level = l;
    }
}

